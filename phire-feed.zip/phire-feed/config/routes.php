<?php

return [
    '/feed[/]' => [
        'controller' => 'Phire\Feed\Controller\IndexController',
        'action'     => 'feed'
    ]
];
